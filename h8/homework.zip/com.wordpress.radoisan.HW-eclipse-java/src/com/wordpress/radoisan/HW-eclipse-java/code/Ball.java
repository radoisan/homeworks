﻿/* ELSYS
 * www.elsys-bg.org
 * 11Б клас
 * Радослав МИхайлов МИхайлов
 * Номер 26
 * Задача - да се направи програма, която да слага топчета в кутия
 * 
 */
package com.wordpress.radoisan.HW-eclipse-java.code;

public class Ball {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
