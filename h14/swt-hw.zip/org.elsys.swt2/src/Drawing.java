import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class Drawing {

	private DrawingPoint start;
	private DrawingPoint end;
	private DrawingPoint movePoint;

	public static void main(String[] args) {
		Drawing d = new Drawing();
		d.createCanvas();
	}

	public void createCanvas() {
		Display d = new Display();
		Shell shell = new Shell(d);
		shell.setLayout(new FillLayout());
		Shell shell2 = new Shell(d);
		shell2.setSize(300, 100);
		final Text text = new Text(shell2, SWT.BORDER);
		shell2.setLayout(new FillLayout());

		Button compute = new Button(shell2, SWT.PUSH);
		compute.setText("Compute");
		
		shell2.open();
		final Canvas canvas = new Canvas(shell, SWT.BORDER);
		canvas.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_WHITE));
		final List<DrawingPoint> points = new ArrayList<DrawingPoint>();
		compute.addMouseListener(new MouseListener(){

			@Override
			public void mouseDoubleClick(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseDown(MouseEvent arg0) {
				String array[] = text.getText().split(":");
				switch (array[0]){
				case "p" : text.setText(Double.toString(perimeter(points, array[1].split(","))));				
							break;
				case "s" : text.setText(Double.toString(lice(points, array[1].split(","))));				
							break;
				case "angle" : text.setText(Double.toString(calcAngle(points, array[1].split(","))));				
							break;
				case "angles": ArrayList<Double> anglesList = calcAllAngles(points, array[1].split(","));
								text.setText(Double.toString(anglesList.get(0)) + ", " +  Double.toString(anglesList.get(1)) + ", "  + Double.toString(anglesList.get(2)));
				}
			}

			@Override
			public void mouseUp(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		canvas.addMouseMoveListener(new MouseMoveListener() {

			@Override
			public void mouseMove(MouseEvent e) {
				end = new DrawingPoint(e.x, e.y);
				canvas.redraw();
			}

		});
		canvas.addMouseListener(new MouseListener() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}

			@Override
			public void mouseDown(MouseEvent e) {
				if (e.button == 1) {
					start = new DrawingPoint(e.x, e.y);
				} else if (e.button == 3) {
					movePoint = findPoint(points, e.x, e.y);
				}
			}

			@Override
			public void mouseUp(MouseEvent e) {
				if (e.button == 1) {
					points.add(start);
					start.title = Integer.toString(points.size());
					// points.add(new Point(e.x, e.y));
					// start = null;
					canvas.redraw();
				} else if (e.button == 3) {
					movePoint = null;
				}
			}

		});
		canvas.addPaintListener(new PaintListener() {

			@Override
			public void paintControl(PaintEvent e) {
				drawLines(points, e.gc);
			}
		});
		shell.open();

		while (!shell.isDisposed()) {
			if (!d.readAndDispatch()) {
				d.sleep();
			}
		}
	}

	private DrawingPoint findPoint(List<DrawingPoint> points, int x, int y) {
		for (DrawingPoint p : points) {
			if (Math.abs(p.x - x) < 5 && Math.abs(p.y - y) < 5)
				return p;
		}
		return null;
	}

	private void drawLines(final List<DrawingPoint> points, GC gc) {
		if (movePoint != null) {
			movePoint.x = end.x;
			movePoint.y = end.y;
		}
		// if (start != null && end != null) {
		// gc.drawLine(start.x, start.y, end.x, end.y);
		// }
		for (int i = 0; i < points.size(); i++) {
			DrawingPoint p1 = points.get(i);
			gc.drawOval(p1.x - 4, p1.y - 4, 8, 8);
			gc.drawText(p1.title, p1.x + 4, p1.y + 4);
			for (int k = i + 1; k < points.size(); k++) {
				DrawingPoint p2 = points.get(k);
				int xnew;
				int ynew;
				if (p1.x > p2.x) {
					xnew = (p1.x - p2.x) / 2 + p2.x;
				} else {
					xnew = (p2.x - p1.x) / 2 + p1.x;
				}
				if (p1.y > p2.y) {
					ynew = (p1.y - p2.y) / 2 + p2.y;
				} else {
					ynew = (p2.y - p1.y) / 2 + p1.y;
				}
				int distance = (int) Math.pow(
						(Math.pow(Math.abs(p1.x - p2.x), 2) + Math.pow(
								Math.abs(p1.y - p2.y), 2)), 0.5);
				gc.drawText(Integer.toString(distance) + "px", xnew, ynew);
				gc.drawLine(p1.x, p1.y, p2.x, p2.y);
			}
		}
		// for (int i = 0; i < points.size(); i++) {
		// Point start = points.get(i);
		// Point end = points.get(++i);
		// gc.drawLine(start.x, start.y, end.x, end.y);
		// }
	}
	
	private double getDistance(DrawingPoint p1, DrawingPoint p2) {
		double distance =  Math.pow(
				(Math.pow(Math.abs(p1.x - p2.x), 2) + Math.pow(
						Math.abs(p1.y - p2.y), 2)), 0.5);
		return distance;
	}
	
	public double perimeter(List<DrawingPoint> pointsList, String array[]) {
		ArrayList<DrawingPoint> workPointsList = new ArrayList<DrawingPoint>();
		for(int i = 0; i < array.length; i++) {
			for(int k = 0; k < pointsList.size(); k++) {
				if(pointsList.get(k).title.equals(array[i])) {
					workPointsList.add(pointsList.get(k));
					break;
				}
			}
			
		}
		double perimeter = 0;
		for(int i = 0; i < workPointsList.size(); i++) {
			for(int k = i + 1; k < workPointsList.size(); k++) {
				perimeter += getDistance(workPointsList.get(i), workPointsList.get(k));
			}
			
		}
		
		return perimeter;
	}
	
	public double lice(List<DrawingPoint> pointsList, String array[]) {
		ArrayList<DrawingPoint> workPointsList = new ArrayList<DrawingPoint>();
		for(int i = 0; i < array.length; i++) {
			for(int k = 0; k < pointsList.size(); k++) {
				if(pointsList.get(k).title.equals(array[i])) {
					workPointsList.add(pointsList.get(k));
					break;
				}
			}
			
		}
		
		double p = perimeter(pointsList, array) / 2;
		double lice = 0;
		ArrayList<Double> strani = new ArrayList<Double>();
		for(int i = 0; i < workPointsList.size(); i++) {
			for(int k = i + 1; k < workPointsList.size(); k++) {
				strani.add(getDistance(workPointsList.get(i), workPointsList.get(k)));
			}
		}
		
		lice = Math.sqrt(p*(p - strani.get(0))*(p - strani.get(1))*(p - strani.get(2)));
		return (lice);
	}
	
	public double calcAngle(List<DrawingPoint> pointsList, String array[]) {
		ArrayList<DrawingPoint> workPointsList = new ArrayList<DrawingPoint>();
		for(int i = 0; i < array.length; i++) {
			for(int k = 0; k < pointsList.size(); k++) {
				if(pointsList.get(k).title.equals(array[i])) {
					workPointsList.add(pointsList.get(k));
					break;
				}
			}
			
		}
		
		double a = getDistance(workPointsList.get(1), workPointsList.get(2));
		double b = getDistance(workPointsList.get(0), workPointsList.get(2));
		double c = getDistance(workPointsList.get(0), workPointsList.get(1));
		double angle = Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c,2);
		angle /= 2*a*b;
		return Math.toDegrees(Math.acos(angle));
	}
	
	public ArrayList<Double> calcAllAngles(List<DrawingPoint> pointsList, String array[]) {
		ArrayList<DrawingPoint> workPointsList = new ArrayList<DrawingPoint>();
		for(int i = 0; i < array.length; i++) {
			for(int k = 0; k < pointsList.size(); k++) {
				if(pointsList.get(k).title.equals(array[i])) {
					workPointsList.add(pointsList.get(k));
					break;
				}
			}
			
		}
		
		double a = getDistance(workPointsList.get(1), workPointsList.get(2));
		double b = getDistance(workPointsList.get(0), workPointsList.get(2));
		double c = getDistance(workPointsList.get(0), workPointsList.get(1));
		double angley = Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c,2);
		angley /= 2*a*b;
		angley = Math.toDegrees(Math.acos(angley));
		
		double angleb = Math.pow(a, 2) + Math.pow(c, 2) - Math.pow(b, 2);
		angleb /= 2*a*c;
		angleb = Math.toDegrees(Math.acos(angleb));
		
		double anglea = Math.pow(c, 2) + Math.pow(b, 2) -  Math.pow(a, 2);
		anglea /= 2*b*c;
		anglea = Math.toDegrees(Math.acos(anglea));
		ArrayList<Double> anglesList = new ArrayList<Double>();
		anglesList.add(anglea);
		anglesList.add(angleb);
		anglesList.add(angley);
		return anglesList;
	}
}
