package org.elsys.Fib;

public class PowerOnEvaluator extends IEvaluators{
	private int power;
	
	PowerOnEvaluator(int power) {
		this.setPower(power);
	}
	
	public Double evaluate() {
		Double result = (double) 0;
		int power = getPower();
		for(Double d : getEvaluatorList()) {
			d = Math.pow(d, power);
			result += d;
		}
		return result;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}
}