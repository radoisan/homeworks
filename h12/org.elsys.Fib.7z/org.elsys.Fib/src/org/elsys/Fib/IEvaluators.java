package org.elsys.Fib;

import java.util.ArrayList;

public class IEvaluators implements IEvaluator{
	private ArrayList<Double> evaluatorList = new ArrayList<Double>();
	
	public void add(double d) {
		getEvaluatorList().add(d);
	}
	
	public Double evaluate() {
		double result = 0;
		for(Double d : getEvaluatorList()) {
			result += d;
		}
		return result;
	}

	public ArrayList<Double> getEvaluatorList() {
		return evaluatorList;
	}

	public void setEvaluatorList(ArrayList<Double> evaluatorList) {
		this.evaluatorList = evaluatorList;
	}
}
