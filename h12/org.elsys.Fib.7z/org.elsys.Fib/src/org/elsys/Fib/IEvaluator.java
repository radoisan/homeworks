package org.elsys.Fib;

public interface IEvaluator {
	void add(double d);
	
	Double evaluate();
}

